import static org.junit.Assert.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

import org.junit.Test;

import com.simon.container.Renderer;

public class RendererTest {

	@Test
	public void test() {
		Renderer renderer = new Renderer();
		renderer.paintComponents(null);
	}

}
