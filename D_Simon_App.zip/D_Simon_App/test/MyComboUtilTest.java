import static org.junit.Assert.*;

import org.junit.Test;

public class MyComboUtilTest {

	@Test
	public void test() {
	}

}
