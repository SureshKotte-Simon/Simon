import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.simon.container.DappContainer;
import com.simonexceptions.ContainerInstantiationFailedException;

public class DappContainerTest {
	DappContainer cntainer =null;
	
	@BeforeClass
	public void createDappContainer(){
		 cntainer = new DappContainer();
	}
	
	@Test(expected = ContainerInstantiationFailedException.class)
	public void test() {
		cntainer.createContainer(null);	
	}
}
