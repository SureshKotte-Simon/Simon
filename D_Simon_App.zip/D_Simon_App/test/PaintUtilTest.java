import static org.junit.Assert.*;

import org.junit.Test;

public class PaintUtilTest {

	@Test
	public void test() {
	}

}
