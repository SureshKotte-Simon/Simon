import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ DappContainerTest.class, MyComboUtilTest.class, PaintUtilTest.class, RendererTest.class })
public class SimonTestSuite {

}
