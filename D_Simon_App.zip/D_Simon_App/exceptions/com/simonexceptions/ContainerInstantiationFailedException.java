package com.simonexceptions;

public class ContainerInstantiationFailedException extends RuntimeException{

	public ContainerInstantiationFailedException() {
		super("DappContainer class has not been instantiated");
	}
	
}
