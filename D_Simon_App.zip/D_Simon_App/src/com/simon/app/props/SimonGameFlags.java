package com.simon.app.props;

public class SimonGameFlags {
	public static boolean isStartBtnCLicked;

	public boolean isStartBtnCLicked() {
		return isStartBtnCLicked;
	}

	public void setStartBtnCLicked(boolean isStartBtnCLicked) {
		this.isStartBtnCLicked = isStartBtnCLicked;
	}
	
}
