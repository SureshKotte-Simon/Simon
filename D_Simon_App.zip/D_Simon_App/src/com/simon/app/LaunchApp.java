package com.simon.app;

import com.simon.container.DappContainer;

public class LaunchApp {

	public static void main(String[] args) {
		DappContainer dappContainer = new DappContainer();
		dappContainer.createContainer(dappContainer);
	}

}
