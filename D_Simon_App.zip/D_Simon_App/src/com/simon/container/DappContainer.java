package com.simon.container;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableCellRenderer;

import com.simon.app.props.SimonGameFlags;
import com.simon.container.utils.MyComboutil;
import com.simon.container.utils.PaintUtil;

import jaco.mp3.player.MP3Player;

import javax.swing.JComboBox;
import javax.swing.JDialog;

import java.awt.SystemColor;
import javax.swing.SwingConstants;



public class DappContainer implements ActionListener, MouseListener{

	public static DappContainer dappContainer;

	public Renderer renderer;

	public static final int WIDTH =500, HEIGHT = 500;
	
	public static final String DEFAULT_BUTTONS = "Default";
	public static final String TWO_BUTTONS = "Two";
	public static final String THREE_BUTTONS = "Three";
	public static final String FOUR_BUTTONS = "Four";
	public static final String FIVE_BUTTONS = "Five";
	
	public static final String DEFAULT_SPEED = "Default";
	public static final String BASIC_SPEED = "Basic";
	public static final String MEDIUM_SPEED = "Medium";
	public static final String ADVANCED_SPEED = "Advanced";


	public int flashed = 0, dark, ticks=0, indexPattern;

	public boolean creatingPattern = false;

	public ArrayList<Integer> pattern = new ArrayList<Integer>();

	public Random random=new Random();

	private boolean gameOver;
	
	private String PlayerName="";
	private int noOfButtons=MyComboutil.getNoOfButtons(" ");
	private Timer timer;
	public boolean ifStarted=false;
	private static int intialScore=0;
	private JButton customizeBtn;
	private JButton scoreLadder;
	MP3Player mpPlayer;
	String buttonDropDown[] = null;  
	String levelArr[]= null;
	private JTextField userNameField;
	private JLabel statusLabel;
	private JLabel levelLabel;
	private JLabel userNameLabel;
	private JLabel noOfBtnLabel;
	private JButton startBtn;
	private JButton saveBtn;
	private JButton exitButton;
	private JComboBox levelDropDown;
	private JComboBox comboBox;
	private JTextField highScore;
	public static JTextField currentScore;
	private int currentSelection;
	private int currentSelectedLevel;
	private String currentSelectedPlayer;
	private JFrame frame =null;
	private HashMap<String, String> map = new HashMap<>();

	public DappContainer()
	{
		buttonDropDown = new String[]{DappContainer.DEFAULT_BUTTONS,DappContainer.TWO_BUTTONS,DappContainer.THREE_BUTTONS,DappContainer.FOUR_BUTTONS,DappContainer.FIVE_BUTTONS};
		levelArr = new String[]{DappContainer.DEFAULT_SPEED,DappContainer.BASIC_SPEED,DappContainer.MEDIUM_SPEED,DappContainer.ADVANCED_SPEED};
	}

	public void createContainer(DappContainer dappContainer) {
		DappContainer.dappContainer = dappContainer;
		frame = createFrame();
		
		createButtonDropDown();
		createUserNameLable();
		
		createSaveButton();
		
		noOfButtonLable();
		
		createStatusLable();
		
		createLevelLable();
		
		/*String level = (String)levelDropDown.getSelectedItem();
		 if(level.equalsIgnoreCase(" ")){ levelDropDown.setSelectedIndex(3); }
		 */
		createStartButton();
		
		createExitButton();
		
		createCustomizeButton();
		
		scoreLadder();
		
		createCurrentScore();
		
		createHighScoreField();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		start();
	}

	private void createHighScoreField() {
		JLabel lblNewLabel_1 = new JLabel("High Score");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 24));
		lblNewLabel_1.setBounds(383, 553, 163, 34);
		renderer.add(lblNewLabel_1);
		
		highScore = new JTextField();
		highScore.setFont(new Font("Arial Black", Font.PLAIN, 24));
		highScore.setBounds(538, 560, 146, 26);
		renderer.add(highScore);
		highScore.setColumns(10);
		highScore.setEditable(false);
	}

	private void createCurrentScore() {
		if(currentScore==null) {
			currentScore = new JTextField();
		}
		currentScore.setFont(new Font("Arial Black", Font.PLAIN, 24));
		currentScore.setBounds(217, 560, 146, 26);
		
		renderer.add(currentScore);
		currentScore.setColumns(10);
		currentScore.setEditable(false);
		
		JLabel lblNewLabel = new JLabel("Current Score");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
		lblNewLabel.setBounds(15, 553, 203, 40);
		renderer.add(lblNewLabel);
	}

	private void createCustomizeButton() {
		customizeBtn = new JButton("Customize");
		customizeBtn.setForeground(new Color(233, 150, 122));
		customizeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox.setVisible(true);
				comboBox.setEnabled(true);
				userNameLabel.setVisible(true);
				userNameField.setVisible(true);
				saveBtn.setEnabled(true);
				saveBtn.setVisible(true);
				noOfBtnLabel.setVisible(true);
				levelLabel.setVisible(true);
				levelDropDown.setVisible(true);
				levelDropDown.setEditable(true);
				exitButton.setVisible(true);
				startBtn.setEnabled(false);
				currentSelection = comboBox.getSelectedIndex();
			}
		});
		customizeBtn.setFont(new Font("Arial Black", Font.PLAIN, 24));
		customizeBtn.setBounds(569, 42, 188, 40);
		renderer.add(customizeBtn);
	}
	
	private void scoreLadder() {
		
		scoreLadder = new JButton("scoreLadder");
		scoreLadder.setForeground(new Color(233, 150, 122));
		scoreLadder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[][] array = new String[map.size()][2];
				int count = 0;
				TreeMap<String, String> treeMap = new TreeMap<String, String>();
				treeMap.putAll(map);
				for(Map.Entry<String,String> entry : treeMap.entrySet()){
				    array[count][0] = entry.getKey();
				    array[count][1] = entry.getValue();
				    count++;
				}
				JDialog dialog = new JDialog(frame);
				JTable table= new JTable(array, new String[] {"UserName","Score"});
				table.setEnabled(false);
		       	DefaultTableCellRenderer defaultTableCellRenderer = (DefaultTableCellRenderer)table.getDefaultRenderer(Object.class);
		       	defaultTableCellRenderer.setHorizontalAlignment( SwingConstants.CENTER );
				dialog.add(table);
				dialog.setVisible(true);
				dialog.setSize(200,200);
				dialog.setModal(true);
				dialog.setLocationRelativeTo(null);
				dialog.setLayout(new BorderLayout());
				JScrollPane scrollPane = new JScrollPane(table);
				dialog.add(scrollPane, BorderLayout.CENTER);
				dialog.setTitle("Score Ladder");
				//dialog.add(table,BorderLayout.CENTER);
				dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
				//frame.getContentPane().add(dialog);
			}
		});
		scoreLadder.setFont(new Font("Arial Black", Font.PLAIN, 24));
		scoreLadder.setBounds(700, 433, 115, 29);
		renderer.add(scoreLadder);
	}

	private void createExitButton() {
		exitButton = new JButton("Exit");
		exitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox.setVisible(false);
				comboBox.setEnabled(false);
				userNameLabel.setVisible(false);
				userNameField.setVisible(false);
				saveBtn.setEnabled(false);
				saveBtn.setVisible(false);
				noOfBtnLabel.setVisible(false);
				levelLabel.setVisible(false);
				levelDropDown.setVisible(false);
				levelDropDown.setEditable(false);
				exitButton.setVisible(false);
				userNameField.setText("Player01");
				ifStarted=false;
				startBtn.setEnabled(true);
				if(!currentSelectedPlayer.equalsIgnoreCase("Player 01")) {
					userNameField.setText(currentSelectedPlayer);
				}
				levelDropDown.setSelectedIndex(currentSelectedLevel);
				System.out.println("currentSelection:"+currentSelection);
				if(currentSelection>0) {
					comboBox.setSelectedIndex(currentSelection);
				}
				int interval=MyComboutil.getTimerSpeed((String)levelDropDown.getSelectedItem());
				timer.setDelay(interval);
				timer.start();
			}
		});
		exitButton.setForeground(Color.RED);
		exitButton.setFont(new Font("Arial Black", Font.PLAIN, 24));
		exitButton.setBounds(700, 433, 115, 29);
		renderer.add(exitButton);
		exitButton.setVisible(false);
	}

	private void createStartButton() {
		startBtn = new JButton("Start");
		startBtn.setBounds(177, 196, 141, 107);
		startBtn.setForeground(Color.WHITE);
		startBtn.setBackground(Color.BLACK);
		renderer.add(startBtn);
		startBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Button Clicked");
				if(timer==null) {
					timer = new Timer(20, this);
				}
				if(!timer.isRunning()) {
					timer.start();
				}
				startBtn.setEnabled(false); 
				startBtn.setVisible(false);
				ifStarted=true;
				SimonGameFlags.isStartBtnCLicked=true;
				if(currentScore==null) {
					currentScore = new JTextField();
				}
				if(renderer==null) {
					renderer = new Renderer();
				}
				System.out.println("----dood----->");
				renderer.setBackground(Color.GRAY);
				buttonDropDown= null;
				currentScore.setText("  "+0+"");
				intialScore=pattern.size();
				comboBox.setEnabled(false);
				comboBox.setVisible(false);
				//levelDropDown.gett
				String noOfBittons=(String)comboBox.getSelectedItem();
				System.out.println("noOfBittons::::;"+comboBox.getSelectedItem().toString());
				currentSelection = comboBox.getSelectedIndex();
				currentSelectedLevel = levelDropDown.getSelectedIndex();
				currentSelectedPlayer = userNameField.getText();
				noOfButtons=MyComboutil.getNoOfButtons(noOfBittons);
				String level=(String)levelDropDown.getSelectedItem();
				int interval=MyComboutil.getTimerSpeed(level);
				timer.setDelay(interval);
				statusLabel.setText(" "+userNameField.getText()+" Watch");
				comboBox.setVisible(false);
				comboBox.setEnabled(false);
				userNameLabel.setVisible(false);
				userNameField.setVisible(false);
				saveBtn.setEnabled(false);
				saveBtn.setVisible(false);
				noOfBtnLabel.setVisible(false);
				levelLabel.setVisible(false);
				levelDropDown.setVisible(false);
				levelDropDown.setEditable(false);
				exitButton.setVisible(false);
				customizeBtn.setVisible(false);
			}
		});
	}

	private void createLevelLable() {
		levelLabel = new JLabel("Level");
		levelLabel.setForeground(new Color(255, 255, 224));
		levelLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
		levelLabel.setBounds(569, 319, 141, 32);
		renderer.add(levelLabel);
		levelLabel.setVisible(false);
		levelDropDown = new JComboBox(levelArr);
		//levelDropDown.setFont(new Font("Arial Black", Font.PLAIN, 15));
		levelDropDown.setBounds(569, 349, 188, 40);
		renderer.add(levelDropDown);
		levelDropDown.setVisible(false);
		levelDropDown.setEditable(false);
	}

	private void createStatusLable() {
		statusLabel = new JLabel("Ready");
		statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
		statusLabel.setForeground(new Color(128, 0, 0));
		statusLabel.setFont(new Font("Arial Black", Font.PLAIN, 26));
		statusLabel.setBounds(50, 500, 434, 49);
		renderer.add(statusLabel);
	}

	private void noOfButtonLable() {
		noOfBtnLabel = new JLabel("No of buttons");
		noOfBtnLabel.setForeground(SystemColor.info);
		noOfBtnLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
		noOfBtnLabel.setBounds(569, 143, 188, 30);
		renderer.add(noOfBtnLabel);
		noOfBtnLabel.setVisible(false);
	}

	private void createSaveButton() {
		saveBtn = new JButton("Save");
		saveBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String noOfBittons=(String)comboBox.getSelectedItem();
				noOfButtons=MyComboutil.getNoOfButtons(noOfBittons);
				PlayerName=userNameField.getText();
				System.out.println("PlayerName---->"+PlayerName);

				comboBox.setVisible(false);
				comboBox.setEnabled(false);
				userNameLabel.setVisible(false);
				userNameField.setVisible(false);
				saveBtn.setEnabled(false);
				saveBtn.setVisible(false);
				noOfBtnLabel.setVisible(false);
				
				levelLabel.setVisible(false);
				levelDropDown.setVisible(false);
				levelDropDown.setEditable(false);
				exitButton.setVisible(false);
				String no=(String)comboBox.getSelectedItem();
				noOfButtons=MyComboutil.getNoOfButtons(no);
				String level=(String)levelDropDown.getSelectedItem();
				int interval=MyComboutil.getTimerSpeed(level);
				timer.setDelay(interval);
				timer.start();
				ifStarted=false;
				startBtn.setEnabled(true);
			}
		});
		saveBtn.setForeground(Color.RED);
		saveBtn.setFont(new Font("Arial Black", Font.PLAIN, 24));
		saveBtn.setBounds(569, 433, 115, 29);
		renderer.add(saveBtn);
		saveBtn.setVisible(false);
		saveBtn.setEnabled(false);
	}

	private void createUserNameLable() {
		userNameLabel = new JLabel("UserName");
		userNameLabel.setForeground(SystemColor.info);
		userNameLabel.setFont(new Font("Arial Black", Font.PLAIN, 24));
		userNameLabel.setBounds(569, 232, 188, 26);
		renderer.add(userNameLabel);
		userNameLabel.setVisible(false);
		userNameField = new JTextField("Player1");
		//userNameField.setFont(new Font("Arial Black", Font.PLAIN, 24));
		userNameField.setBounds(569, 263, 212, 40);
		renderer.add(userNameField);
		userNameField.setColumns(10);
		userNameField.setVisible(false);
	}

	private void createButtonDropDown() {
		comboBox = new JComboBox(buttonDropDown);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String noOfBittons=(String)comboBox.getSelectedItem();
				//noOfButtons=MyComboutil.getNoOfButtons(noOfBittons);
				System.out.println("----noOfBittons--->"+noOfBittons);
				renderer.setBackground(Color.GRAY);
			}
		});
		comboBox.setBounds(569, 175, 188, 34);
		System.out.println("------------->"+SimonGameFlags.isStartBtnCLicked);
		if(!SimonGameFlags.isStartBtnCLicked) {
			renderer.add(comboBox);
		}
		comboBox.setVisible(false);
		comboBox.setEnabled(false);
	}

	private JFrame createFrame() {
		JFrame frame = new JFrame("Simon");
		timer = new Timer(10, this);

		renderer = new Renderer();
		renderer.setBackground(Color.GRAY);

		frame.setSize(818, 646);
		frame.setVisible(true);
		frame.addMouseListener(this);
		frame.setResizable(false);
		frame.getContentPane().add(renderer);
		renderer.setLayout(null);
		return frame;
	}

	public void start()
	{
		renderer.setBackground(Color.GRAY);
		random = new Random();
		pattern = new ArrayList<Integer>();
		indexPattern = 0;
		dark = 2;
		flashed = 0;
		ticks = 0;
		SimonGameFlags.isStartBtnCLicked=false;
		renderer.add(comboBox);
	}

	/*
	 * public static void main(String[] args) { dappContainer = new DappContainer();
	 * }
	 */

	@Override
	public void actionPerformed(ActionEvent e)
	{
		System.out.println("DappContainer.actionPerformed()");
		ticks++;

		if (ticks % 20 == 0)
		{
			flashed = 0;

			if (dark >= 0)
			{
				dark--;
			}
		}

		if (creatingPattern && ifStarted)
		{
			
			if (dark <= 0)
			{
				if (indexPattern >= pattern.size())
				{
					statusLabel.setText(" "+userNameField.getText()+" Play");
					flashed = random.nextInt(40) % noOfButtons + 1;
					pattern.add(flashed);
					indexPattern = 0;
					creatingPattern = false;
				}
				else
				{
					int currScore = pattern.size()>0 ? pattern.size() : 0;
					currentScore.setText("  "+currScore+"");
					statusLabel.setText(" "+userNameField.getText()+" Watch");
					flashed = pattern.get(indexPattern);
					indexPattern++;
				}

				dark = 2;
			}
		}
		else if (indexPattern == pattern.size())
		{
			creatingPattern = true;
			indexPattern = 0;
			dark = 2;
		}
		
		renderer.repaint();
	}

	public void paint(Graphics2D g)
	{
		SimonPropBean simonPropBean=new SimonPropBean();
		simonPropBean.setWIDTH(WIDTH);
		simonPropBean.setHEIGHT(HEIGHT);
		simonPropBean.setPattern(pattern);
		simonPropBean.setGameOver(gameOver);
		simonPropBean.setFlashed(flashed);
		renderer.setBackground(Color.GRAY);
		new PaintUtil().fillColorOnChoice(noOfButtons,g,simonPropBean);
		
	}

	@Override
	public void mousePressed(MouseEvent e)
	{
		if(ifStarted) {
			statusLabel.setText(" "+userNameField.getText()+" Play");
			int x = e.getX(), y = e.getY();

			if (!creatingPattern && !gameOver  && noOfButtons==4)
			{
				if (x > 0 && x < WIDTH / 2 && y > 0 && y < HEIGHT / 2)
				{
					flashed = 1;
					ticks = 1;
					mpPlayer=new MP3Player(new File("src\\sounds\\Green.mp3"));
					mpPlayer.play();
				}
				else if (x > WIDTH / 2 && x < WIDTH && y > 0 && y < HEIGHT / 2)
				{
					flashed = 2;
					ticks = 1;
					mpPlayer=new MP3Player(new File("src\\sounds\\Red.mp3"));
					mpPlayer.play();
				}
				else if (x > 0 && x < WIDTH / 2 && y > HEIGHT / 2 && y < HEIGHT)
				{
					flashed = 3;
					ticks = 1;
					mpPlayer=new MP3Player(new File("src\\sounds\\Orange.mp3"));
					mpPlayer.play();
				}
				else if (x > WIDTH / 2 && x < WIDTH && y > HEIGHT / 2 && y < HEIGHT)
				{
					flashed = 4;
					ticks = 1;
					mpPlayer=new MP3Player(new File("src\\sounds\\Blue.mp3"));
					mpPlayer.play();
				}

				if (flashed != 0)
				{
					if (pattern.get(indexPattern) == flashed)
					{
						indexPattern++;
					}
					else
					{
						gameOver = true;
						customizeBtn.setVisible(true);
						ifStarted=false;
						statusLabel.setText(" "+userNameField.getText()+" Game Over");
						if(highScore!=null && pattern.size()>intialScore ) {
							highScore.setText("  "+(pattern.size()-1)+"");
							map.put(userNameField.getText().toUpperCase(), String.valueOf(pattern.size()-1));
							intialScore=intialScore;
						}
						SimonGameFlags.isStartBtnCLicked=false;
						//timer.stop();
						startBtn.setEnabled(true); 
						startBtn.setVisible(true);
						//renderer=null;
					}
				}
			}else if(!creatingPattern && !gameOver && noOfButtons==5) {
				int upperStep=WIDTH/3;
				int downStep=WIDTH/2;
				if (x > 0 && x < upperStep && y > 0 && y < HEIGHT / 2)
				{
					flashed = 1;
					ticks = 1;
				}
				else if (x> upperStep && x < (2*upperStep) && y > 0 && y < HEIGHT / 2)
				{
					flashed = 2;
					ticks = 1;
				}
				else if (x > (upperStep*2)   && x < WIDTH && y> 0 && y < HEIGHT/2)
				{
					flashed = 3;
					ticks = 1;
				}
				else if (x > 0 && x < downStep && y > HEIGHT / 2 && y < HEIGHT)
				{
					flashed = 4;
					ticks = 1;
				}else if (x > downStep && x < (2*downStep) && y > HEIGHT / 2 && y < HEIGHT)
				{
					flashed = 5;
					ticks = 1;
				}
				if (flashed != 0)
				{
					if (pattern.get(indexPattern) == flashed)
					{
						indexPattern++;
					}
					else
					{
						gameOver = true;
						customizeBtn.setVisible(true);
						ifStarted=false;
						statusLabel.setText(" "+userNameField.getText()+" Game Over");
						if(highScore!=null && pattern.size()>intialScore ) {
							highScore.setText("  "+(pattern.size()-1)+"");
							map.put(userNameField.getText().toUpperCase(), String.valueOf(pattern.size()-1));
							intialScore=intialScore;
						}
						SimonGameFlags.isStartBtnCLicked=false;
						//timer.stop();
						startBtn.setEnabled(true); 
						startBtn.setVisible(true);
						//renderer=null;
						
					}
				}	
			}else if(!creatingPattern && !gameOver && noOfButtons==3) {
				if (x > 0 && x < WIDTH / 2 && y > 0 && y < HEIGHT / 2)
				{
					flashed = 1;
					ticks = 1;
				}
				else if (x > WIDTH / 2 && x < WIDTH && y > 0 && y < HEIGHT / 2)
				{
					flashed = 2;
					ticks = 1;
				}
				else if (y > HEIGHT / 2 && y < HEIGHT)
				{
					flashed = 3;
					ticks = 1;
				}
				if (flashed != 0)
				{
					if (pattern.get(indexPattern) == flashed)
					{
						indexPattern++;
					}
					else
					{
						gameOver = true;
						customizeBtn.setVisible(true);
						ifStarted=false;
						statusLabel.setText(" "+userNameField.getText()+" Game Over");
						if(highScore!=null && pattern.size()>intialScore ) {
							highScore.setText("  "+(pattern.size()-1)+"");
							map.put(userNameField.getText().toUpperCase(), String.valueOf(pattern.size()-1));
							intialScore=intialScore;
						}
						SimonGameFlags.isStartBtnCLicked=false;
						//timer.stop();
						startBtn.setEnabled(true); 
						startBtn.setVisible(true);
					}
				}
			}else if(!creatingPattern && !gameOver && noOfButtons==2) {
				if (x>0 && x < WIDTH && y > 0 && y < HEIGHT / 2)
				{
					System.out.println("Flashed...");
					flashed = 1;
					ticks = 1;
				}
				if(y > HEIGHT / 2 && y<HEIGHT && y< WIDTH) {
					flashed = 2;
					ticks = 1;
				}
				if (flashed != 0)
				{
					if (pattern.get(indexPattern) == flashed)
					{
						indexPattern++;
					}
					else
					{
						gameOver = true;
						customizeBtn.setVisible(true);
						ifStarted=false;
						statusLabel.setText(" "+userNameField.getText()+" Game Over");
						if(highScore!=null && pattern.size()>intialScore ) {
							highScore.setText("  "+(pattern.size()-1)+"");
							map.put(userNameField.getText().toUpperCase(), String.valueOf(pattern.size()-1));
							intialScore=intialScore;
						}
						SimonGameFlags.isStartBtnCLicked=false;
						renderer.add(comboBox);
						//timer.stop();
						startBtn.setEnabled(true); 
						startBtn.setVisible(true);
						//renderer=null;
					}
				}

			}else if (gameOver)
			{
				start();
				gameOver = false;
				//ifStarted=false;
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e)
	{
	}

	@Override
	public void mouseReleased(MouseEvent e)
	{
	}

	@Override
	public void mouseEntered(MouseEvent e)
	{
	}

	@Override
	public void mouseExited(MouseEvent e)
	{
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
