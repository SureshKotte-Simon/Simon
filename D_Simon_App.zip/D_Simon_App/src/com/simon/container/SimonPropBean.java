package com.simon.container;

import java.util.ArrayList;

public class SimonPropBean {
	private int WIDTH, HEIGHT;
	private int flashed = 0, dark, ticks, indexPattern;
	private boolean gameOver;
	private boolean creatingPattern = true;
	private ArrayList<Integer> pattern;
	
	public int getFlashed() {
		return flashed;
	}
	public void setFlashed(int flashed) {
		this.flashed = flashed;
	}
	public int getDark() {
		return dark;
	}
	public void setDark(int dark) {
		this.dark = dark;
	}
	public int getTicks() {
		return ticks;
	}
	public void setTicks(int ticks) {
		this.ticks = ticks;
	}
	public int getIndexPattern() {
		return indexPattern;
	}
	public void setIndexPattern(int indexPattern) {
		this.indexPattern = indexPattern;
	}
	public boolean isGameOver() {
		return gameOver;
	}
	public void setGameOver(boolean gameOver) {
		this.gameOver = gameOver;
	}
	public boolean isCreatingPattern() {
		return creatingPattern;
	}
	public void setCreatingPattern(boolean creatingPattern) {
		this.creatingPattern = creatingPattern;
	}
	public ArrayList<Integer> getPattern() {
		return pattern;
	}
	public void setPattern(ArrayList<Integer> pattern) {
		this.pattern = pattern;
	}
	public int getWIDTH() {
		return WIDTH;
	}
	public void setWIDTH(int wIDTH) {
		WIDTH = wIDTH;
	}
	public int getHEIGHT() {
		return HEIGHT;
	}
	public void setHEIGHT(int hEIGHT) {
		HEIGHT = hEIGHT;
	}
}
