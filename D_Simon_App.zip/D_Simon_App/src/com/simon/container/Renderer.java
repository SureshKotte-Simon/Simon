package com.simon.container;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Renderer extends JPanel
{
	@Override
	protected void paintComponent(Graphics g)
	{
		this.setBackground(Color.GRAY);
		System.out.println("Render Invoked");
		super.paintComponent(g);
		if (DappContainer.dappContainer != null)
		{
			DappContainer.dappContainer.paint((Graphics2D) g);
		}
	}
}
