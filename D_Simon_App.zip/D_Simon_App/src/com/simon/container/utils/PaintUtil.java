package com.simon.container.utils;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import com.simon.container.DappContainer;
import com.simon.container.SimonPropBean;

public class PaintUtil {
	public boolean notStarted;
	public static int currScore;
	
	public void fillColorOnChoice(int n,Graphics2D graph,SimonPropBean simBean) {
		notStarted=false;
		currScore = simBean.getPattern().size()>0 ? simBean.getPattern().size()-1 : 0;
		
		if(n>0) {
			switch(n) {
			case 2:
				paintTwO(graph, simBean);
				break;
			case 3:	
				paintThree(graph, simBean);
				break;
			case 4:	
				paintFour(graph, simBean);
				break;
			case 5:	
				paintFive(graph, simBean);
				break;
			}
		}
		
	}
	
	public void paintTwO(Graphics2D g,SimonPropBean simBean) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		if (simBean.getFlashed() == 1)
		{
			g.setColor(Color.GREEN);
		}
		else
		{
			g.setColor(Color.GREEN.darker());
		}

		g.fillRect(0, 0, simBean.getWIDTH(), simBean.getHEIGHT()/ 2);

		if (simBean.getFlashed() == 2)
		{
			g.setColor(Color.RED);
		}
		else
		{
			g.setColor(Color.RED.darker());
		}

		g.fillRect(0, simBean.getWIDTH()/2, simBean.getWIDTH() , simBean.getWIDTH()/2);

		
		g.setColor(Color.BLACK);
		g.fillRoundRect(200, 200, 100, 100, 80, 80);
		//g.fillRoundRect(350, 350, 120, 120, 80, 80);
		//g.fillRoundRect(220, 220, 350, 350, 300, 300);
		//g.fillRect(simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, 0, simBean.getWIDTH() / 7, simBean.getHEIGHT());
		//g.fillRect(0, simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, simBean.getWIDTH(), simBean.getHEIGHT() / 7);

		g.setColor(Color.GRAY);
		g.setStroke(new BasicStroke(200));
		g.drawOval(-100, -100, simBean.getWIDTH() + 200, simBean.getHEIGHT() + 200);

		g.setColor(Color.BLACK);
		g.setStroke(new BasicStroke(10));
		g.drawOval(0, 0, simBean.getWIDTH(), simBean.getHEIGHT());

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", 1, 150));

		if (simBean.isGameOver())
		{
			//g.drawString(":(", simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}else if(notStarted) {
			////DappContainer.currentScore.setText("  "+currScore+"");
			//g.drawString("Start", simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
		//DappContainer.currentScore.setText("  "+currScore+"");
	}
	
	public void paintThree(Graphics2D g,SimonPropBean simBean) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		if (simBean.getFlashed() == 1)
		{
			g.setColor(Color.GREEN);
		}
		else
		{
			g.setColor(Color.GREEN.darker());
		}

		g.fillRect(0, 0, simBean.getWIDTH() / 2, simBean.getHEIGHT()/ 2);

		if (simBean.getFlashed() == 2)
		{
			g.setColor(Color.RED);
		}
		else
		{
			g.setColor(Color.RED.darker());
		}

		g.fillRect(simBean.getWIDTH()/2, 0, simBean.getWIDTH()-150, simBean.getHEIGHT() / 2);

		if (simBean.getFlashed() == 3)
		{
			g.setColor(Color.BLUE);
		}
		else
		{
			g.setColor(Color.BLUE.darker());
		}

		g.fillRect(0, simBean.getHEIGHT() / 2, simBean.getWIDTH() , simBean.getHEIGHT() / 2);
		g.setColor(Color.BLACK);
		g.fillRoundRect(200, 200, 100, 100, 80, 80);
		//g.fillRoundRect(350, 350, 120, 120, 80, 80);
		//g.fillRoundRect(220, 220, 350, 350, 300, 300);
		//g.fillRect(simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, 0, simBean.getWIDTH() / 7, simBean.getHEIGHT());
		//g.fillRect(0, simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, simBean.getWIDTH(), simBean.getHEIGHT() / 7);

		g.setColor(Color.GRAY);
		g.setStroke(new BasicStroke(200));
		g.drawOval(-100, -100, simBean.getWIDTH() + 200, simBean.getHEIGHT() + 200);

		g.setColor(Color.BLACK);
		g.setStroke(new BasicStroke(10));
		g.drawOval(0, 0, simBean.getWIDTH(), simBean.getHEIGHT());

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", 1, 150));
		

		if (simBean.isGameOver())
		{
			//g.drawString(":(", simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
		else
		{
			//DappContainer.currentScore.setText("  "+currScore+"");
			//g.drawString(simBean.getIndexPattern() + "/" + simBean.getPattern().size(), simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
	}
	
	
	
	
	public void paintFour(Graphics2D g,SimonPropBean simBean) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		if (simBean.getFlashed() == 1)
		{
			g.setColor(Color.GREEN);
		}
		else
		{
			g.setColor(Color.GREEN.darker());
		}

		g.fillRect(0, 0, simBean.getWIDTH() / 2, simBean.getHEIGHT()/ 2);

		if (simBean.getFlashed() == 2)
		{
			g.setColor(Color.RED);
		}
		else
		{
			g.setColor(Color.RED.darker());
		}

		g.fillRect(simBean.getWIDTH() / 2, 0, simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2);
		
		 
		 

		if (simBean.getFlashed() == 3)
		{
			g.setColor(Color.ORANGE);
		}
		else
		{
			g.setColor(Color.ORANGE.darker());
		}

		g.fillRect(0, simBean.getHEIGHT() / 2, simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2);

		if (simBean.getFlashed() == 4)
		{
			g.setColor(Color.BLUE);
		}
		else
		{
			g.setColor(Color.BLUE.darker());
		}

		g.fillRect(simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2, simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2);

		g.setColor(Color.BLACK);
		g.fillRoundRect(200, 200, 100, 100, 80, 80);
		//g.fillRoundRect(220, 220, 350, 350, 300, 300);
		//g.fillRect(simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, 0, simBean.getWIDTH() / 7, simBean.getHEIGHT());
		//g.fillRect(0, simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, simBean.getWIDTH(), simBean.getHEIGHT() / 7);

		g.setColor(Color.GRAY);
		g.setStroke(new BasicStroke(200));
		g.drawOval(-100, -100, simBean.getWIDTH() + 200, simBean.getHEIGHT() + 200);

		g.setColor(Color.BLACK);
		g.setStroke(new BasicStroke(10));
		g.drawOval(0, 0, simBean.getWIDTH(), simBean.getHEIGHT());

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", 1, 120));

		if (simBean.isGameOver())
		{
			//g.drawString(":(", simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
		else
		{
			//DappContainer.currentScore.setText("  "+currScore+"");
			//g.drawString(simBean.getIndexPattern() + "/" + simBean.getPattern().size(), simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
	}
	
	public void paintFive(Graphics2D g,SimonPropBean simBean) {
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		int start=0;
		int step=simBean.getWIDTH() / 3;
		if (simBean.getFlashed() == 1)
		{
			g.setColor(Color.GREEN);
		}
		else
		{
			g.setColor(Color.GREEN.darker());
		}

		g.fillRect(start, 0, step, simBean.getHEIGHT()/ 2);
		start=step;
		step+=step;
		if (simBean.getFlashed() == 2)
		{
			g.setColor(Color.RED);
		}
		else
		{
			g.setColor(Color.RED.darker());
		}

		g.fillRect(start, 0, step, simBean.getHEIGHT() / 2);
		start=step;
		step+=step;
		if (simBean.getFlashed() == 3) {
			System.out.println("Something");
			g.setColor(Color.YELLOW);
		}else {
			System.out.println("Something Something");
			g.setColor(Color.YELLOW.darker());
		}
		g.fillRect(start, 0, simBean.getWIDTH()-250, simBean.getHEIGHT() / 2);

		if (simBean.getFlashed() == 4)
		{
			g.setColor(Color.ORANGE);
		}
		else
		{
			g.setColor(Color.ORANGE.darker());
		}

		g.fillRect(0, simBean.getHEIGHT() / 2, simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2);

		if (simBean.getFlashed() == 5)
		{
			g.setColor(Color.BLUE);
		}
		else
		{
			g.setColor(Color.BLUE.darker());
		}

		g.fillRect(simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2, simBean.getWIDTH() / 2, simBean.getHEIGHT() / 2);

		g.setColor(Color.BLACK);
		g.fillRoundRect(200, 200, 100, 100, 80, 80);
		//g.fillRoundRect(350, 350, 120, 120, 80, 80);
		//g.fillRect(simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, 0, simBean.getWIDTH() / 7, simBean.getHEIGHT());
		//g.fillRect(0, simBean.getWIDTH() / 2 - simBean.getWIDTH() / 12, simBean.getWIDTH(), simBean.getHEIGHT() / 7);

		g.setColor(Color.GRAY);
		g.setStroke(new BasicStroke(200));
		g.drawOval(-100, -100, simBean.getWIDTH() + 200, simBean.getHEIGHT() + 200);

		g.setColor(Color.BLACK);
		g.setStroke(new BasicStroke(10));
		g.drawOval(0, 0, simBean.getWIDTH(), simBean.getHEIGHT());

		g.setColor(Color.WHITE);
		g.setFont(new Font("Arial", 1, 50));

		if (simBean.isGameOver())
		{
			//g.drawString(":(", simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
		else
		{
			//DappContainer.currentScore.setText("  "+currScore+"");
			//g.drawString(simBean.getIndexPattern() + "/" + simBean.getPattern().size(), simBean.getWIDTH() / 2 - 100, simBean.getHEIGHT() / 2 + 42);
		}
	}
}
