package com.simon.container.utils;

public class MyComboutil {
	
	public static int getNoOfButtons(String str) {
		str=str.toLowerCase();
		int result=0;
		switch (str) {
		case "two":
			result= 2;
			break;
		case "three":
			result= 3;
			break;
		case "four":
			result=4;
			break;
		case "five":
			result=5;
			break;	
		default:
			result=4;
			break;
		}
		return result;
	}
	public static int getTimerSpeed(String str) {
		str=str.toLowerCase();
		int result=0;
		switch (str) {
		case "basic":
			result= 50;
			break;
		case "medium":
			result= 20;
			break;
		case "advanced":
			result=10;
			break;
		default:
			result=20;
			break;
		}
		return result;
	}

}
